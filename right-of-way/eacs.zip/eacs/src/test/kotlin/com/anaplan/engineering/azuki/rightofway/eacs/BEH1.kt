package com.anaplan.engineering.azuki.rightofway.eacs

import com.anaplan.engineering.azuki.rightofway.com.anaplan.engineering.azuki.rightofway.dsl.RightOfWayRunnableScenario

abstract class BEH1 : RightOfWayRunnableScenario() {
//    override fun given() {
//        given {
//        }
//    }
}
